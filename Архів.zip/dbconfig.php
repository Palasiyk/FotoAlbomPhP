<?php

    $connect = mysqli_connect("localhost", "root", "root", "dz-myPhP-sql");

    if(!$connect){
        die('ERROR!');
    }
?>
